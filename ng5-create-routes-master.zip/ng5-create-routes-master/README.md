# To clone the  project
->  Open Command-line
-> `git clone https://github.com/techsithgit/ng5-create-routes.git`
-> `cd ng5-create-routes`
-> `npm install`
-> `ng serve --open`


## If you have any questions, feel free to message me on my youtube channel.
youtube.com/techsithtube
