### Class-5 Multiple Component and For-each (*ngFor) directive

- in this chapter, we will learn
  - creating array of contacts instead of one
  - display contacts in <ul></ul> using *ngFor
  - move listing piece of html to contact-list component
  - move detail piece of html to contact component
  - learn how to pass selected contact from contact-list to contact component using inputs:[]
  - final minor plumbing
