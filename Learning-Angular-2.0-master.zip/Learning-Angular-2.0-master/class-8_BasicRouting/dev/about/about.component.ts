import {Component, View} from "angular2/core";
import {ROUTER_DIRECTIVES} from "angular2/router";

@Component({
  selector:'about',
  providers:[],
  directives: [ROUTER_DIRECTIVES],
  templateUrl:'../dev/about/about.component.html'
})
export class AboutComponent{

}
