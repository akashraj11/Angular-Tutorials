import {Contact} from "./contact";

export const CONTACTS: Contact[] = [
  {firstname : "Max" , lastname:"Smith", email:"max@gmail.com"},
  {firstname : "Chris" , lastname:"Raches", email:"chris@gmail.com"},
  {firstname : "Michael" , lastname:"Alloy", email:"michael@gmail.com"},
  {firstname : "John" , lastname:"Doe", email:"john@gmail.com"},
  {firstname: "Jenny", lastname: "Doe", email: "jenny@gmail.com" }
]
