### Class-6 Services, TemplateURL, constructor

- in this chapter, we will learn
  - pre-select first element from contact list using component class constructor
  - create templates for contact, contact-list & app components and refer using templateURL.
  - Write interface class and services
      - define interface / schema of your data
      - define data class
      - define service class
      - inject service class in contact-list component
      - call service method in constructor(q-promise)
      - call service method using lifecycle hooks
  - and some final minor plumbing
