import {Component, View} from "angular2/core";
import {ROUTER_DIRECTIVES} from "angular2/router";

@Component({
  selector:'home',
  providers:[],
  // directives: [ROUTER_DIRECTIVES],
  templateUrl:'../dev/home/home.component.html'
})
export class HomeComponent{

}
