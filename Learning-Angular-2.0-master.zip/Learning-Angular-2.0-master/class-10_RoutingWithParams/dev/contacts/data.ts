import {Contact} from "./contact";

export const CONTACTS: Contact[] = [
  {id:"1", firstname : "Max" , lastname:"Smith", email:"max@gmail.com"},
  {id:"2", firstname : "Chris" , lastname:"Raches", email:"chris@gmail.com"},
  {id:"3", firstname : "Michael" , lastname:"Alloy", email:"michael@gmail.com"},
  {id:"4", firstname : "John" , lastname:"Doe", email:"john@gmail.com"},
  {id:"5", firstname: "Jenny", lastname: "Doe", email: "jenny@gmail.com" }
]
