// This is not going to compile or anything since it's in JS
// This is for better type script practice we are following.
export interface Contact {
  id:string,
  firstname :string,
  lastname: string,
  email : string
}
