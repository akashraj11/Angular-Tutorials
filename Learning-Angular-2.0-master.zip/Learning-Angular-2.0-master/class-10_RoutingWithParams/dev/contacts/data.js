System.register([], function(exports_1) {
    "use strict";
    var CONTACTS;
    return {
        setters:[],
        execute: function() {
            exports_1("CONTACTS", CONTACTS = [
                { id: "1", firstname: "Max", lastname: "Smith", email: "max@gmail.com" },
                { id: "2", firstname: "Chris", lastname: "Raches", email: "chris@gmail.com" },
                { id: "3", firstname: "Michael", lastname: "Alloy", email: "michael@gmail.com" },
                { id: "4", firstname: "John", lastname: "Doe", email: "john@gmail.com" },
                { id: "5", firstname: "Jenny", lastname: "Doe", email: "jenny@gmail.com" }
            ]);
        }
    }
});
//# sourceMappingURL=data.js.map