### Class-10 Routing with Parameters
- In this class, we will learn
    - more about routing in angular 2
    - implementing navigation between pages with Parameters
    - how to work with Routing navigate() with params
    - add code to About component script
    - how to consume parameters into destination form.
    - use of ngOnInit()
    - create new method getContactById in service
    - inject service in to destination typescript (About), and get contact based on passed parameter.
    
