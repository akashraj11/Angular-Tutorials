export const environment = {
  production: false,
  navBarBackgroundColor: 'green'  
};
