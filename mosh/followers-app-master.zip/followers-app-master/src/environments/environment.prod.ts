export const environment = {
  production: true,
  navBarBackgroundColor: 'white'  
};
